﻿namespace Teleperformance.Data
{
    public class RedTagsDto
    {
        public string TagNo { get; set; }
        public string AssetNum { get; set; }
        public string AssetDesc { get; set; }
        public string DatenTime { get; set; }
    }
}
