﻿namespace Teleperformance.Data
{
    public class InboundDto
    {
        public string TagId { get; set; }
    }
}
