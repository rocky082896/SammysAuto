﻿using System.Windows.Controls;

namespace Teleperformance.View
{
    /// <summary>
    /// Interaction logic for InboundView.xaml
    /// </summary>
    public partial class InboundView : UserControl
    {

        public InboundView()
        {
            InitializeComponent();

        }




    }
}
