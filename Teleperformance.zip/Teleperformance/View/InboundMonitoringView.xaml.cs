﻿using System.Windows.Controls;

namespace Teleperformance.View
{
    /// <summary>
    /// Interaction logic for InboundMonitoringView.xaml
    /// </summary>
    public partial class InboundMonitoringView : UserControl
    {
        public InboundMonitoringView()
        {
            InitializeComponent();
        }
    }
}
