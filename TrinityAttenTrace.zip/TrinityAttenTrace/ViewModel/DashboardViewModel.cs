﻿using TrinityAttenTrace.ViewModel.Base;

namespace TrinityAttenTrace.ViewModel
{
    public class DashboardViewModel : ViewModelBase
    {
    }
}
