﻿namespace TrinityAttenTrace.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CreateDb2 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.tblStudent", "ImageSource", c => c.String(maxLength: 200));
        }
        
        public override void Down()
        {
            DropColumn("dbo.tblStudent", "ImageSource");
        }
    }
}
