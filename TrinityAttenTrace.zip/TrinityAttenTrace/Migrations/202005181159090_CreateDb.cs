﻿namespace TrinityAttenTrace.Migrations
{
    using System.Data.Entity.Migrations;

    public partial class CreateDb : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.tblAdviser",
                c => new
                {
                    AdviserId = c.Int(nullable: false, identity: true),
                    Firstname = c.String(nullable: false, maxLength: 35),
                    Lastname = c.String(nullable: false, maxLength: 35),
                    Middlename = c.String(nullable: false, maxLength: 35),
                    DateAdded = c.Binary(nullable: false, fixedLength: true, timestamp: true, storeType: "rowversion"),
                    Status = c.Int(nullable: false),
                    AdviserModel_AdviserId = c.Int(),
                })
                .PrimaryKey(t => t.AdviserId)
                .ForeignKey("dbo.tblAdviser", t => t.AdviserModel_AdviserId)
                .Index(t => t.AdviserModel_AdviserId);

            CreateTable(
                "dbo.tblAnnouncement",
                c => new
                {
                    AnnouncementId = c.Int(nullable: false, identity: true),
                    Description = c.String(nullable: false, maxLength: 100),
                    ValidActive = c.DateTime(nullable: false),
                    ValidUpto = c.DateTime(nullable: false),
                    UserId = c.Int(nullable: false),
                })
                .PrimaryKey(t => t.AnnouncementId)
                .ForeignKey("dbo.tblUser", t => t.UserId, cascadeDelete: true)
                .Index(t => t.UserId);

            CreateTable(
                "dbo.tblUser",
                c => new
                {
                    UserId = c.Int(nullable: false, identity: true),
                    UserName = c.String(nullable: false, maxLength: 11),
                    Password = c.String(nullable: false, maxLength: 11),
                    Firstname = c.String(nullable: false, maxLength: 15),
                    Lastname = c.String(nullable: false, maxLength: 15),
                    Status = c.Int(nullable: false),
                    AccessId = c.Int(nullable: false),
                })
                .PrimaryKey(t => t.UserId);

            CreateTable(
                "dbo.tblSection",
                c => new
                {
                    SectionId = c.Int(nullable: false, identity: true),
                    SectionName = c.String(nullable: false, maxLength: 35),
                    YearLevel = c.Int(nullable: false),
                    SchoolYear = c.Int(nullable: false),
                    Status = c.Int(nullable: false),
                })
                .PrimaryKey(t => t.SectionId);

            CreateTable(
                "dbo.tblSentMessages",
                c => new
                {
                    SentId = c.Int(nullable: false, identity: true),
                    MobileNumber = c.String(maxLength: 11),
                    Status = c.Int(nullable: false),
                })
                .PrimaryKey(t => t.SentId)
                .ForeignKey("dbo.tblStudent", t => t.MobileNumber)
                .Index(t => t.MobileNumber);

            CreateTable(
                "dbo.tblStudent",
                c => new
                {
                    StudentId = c.String(nullable: false, maxLength: 11),
                    Firstname = c.String(nullable: false, maxLength: 35),
                    Lastname = c.String(nullable: false, maxLength: 35),
                    Middlename = c.String(nullable: false, maxLength: 35),
                    Suffix = c.String(nullable: false, maxLength: 4),
                    DateOfBirth = c.DateTime(nullable: false),
                    Guardian = c.String(nullable: false, maxLength: 35),
                    MobileNumber = c.String(nullable: false, maxLength: 15),
                    DateAdded = c.Binary(nullable: false, fixedLength: true, timestamp: true, storeType: "rowversion"),
                    Email = c.String(maxLength: 35),
                    Relationship = c.String(nullable: false, maxLength: 15),
                    Address = c.String(nullable: false, maxLength: 60),
                    Religion = c.String(maxLength: 25),
                    Nationality = c.String(maxLength: 25),
                    RfidTag = c.String(nullable: false, maxLength: 15),
                    Status = c.Int(nullable: false),
                })
                .PrimaryKey(t => t.StudentId);

            CreateTable(
                "dbo.tblStudentIn",
                c => new
                {
                    AttendanceInId = c.Int(nullable: false, identity: true),
                    RfidTag = c.String(maxLength: 11),
                    TimeIn = c.Binary(nullable: false, fixedLength: true, timestamp: true, storeType: "rowversion"),
                })
                .PrimaryKey(t => t.AttendanceInId)
                .ForeignKey("dbo.tblStudent", t => t.RfidTag)
                .Index(t => t.RfidTag);

            CreateTable(
                "dbo.tblStudentOut",
                c => new
                {
                    StudentOutId = c.Int(nullable: false, identity: true),
                    RfidTag = c.String(maxLength: 11),
                    TimeOut = c.Binary(nullable: false, fixedLength: true, timestamp: true, storeType: "rowversion"),
                })
                .PrimaryKey(t => t.StudentOutId)
                .ForeignKey("dbo.tblStudent", t => t.RfidTag)
                .Index(t => t.RfidTag);

            CreateTable(
                "dbo.tblStudentSection",
                c => new
                {
                    StudentSectionId = c.Int(nullable: false, identity: true),
                    SectionId = c.Int(nullable: false),
                    StudentId = c.String(maxLength: 11),
                    AdviserId = c.Int(nullable: false),
                    Status = c.Int(nullable: false),
                })
                .PrimaryKey(t => t.StudentSectionId)
                .ForeignKey("dbo.tblAdviser", t => t.AdviserId, cascadeDelete: true)
                .ForeignKey("dbo.tblSection", t => t.SectionId, cascadeDelete: true)
                .ForeignKey("dbo.tblStudent", t => t.StudentId)
                .Index(t => t.SectionId)
                .Index(t => t.StudentId)
                .Index(t => t.AdviserId);

        }

        public override void Down()
        {
            DropForeignKey("dbo.tblStudentSection", "StudentId", "dbo.tblStudent");
            DropForeignKey("dbo.tblStudentSection", "SectionId", "dbo.tblSection");
            DropForeignKey("dbo.tblStudentSection", "AdviserId", "dbo.tblAdviser");
            DropForeignKey("dbo.tblStudentOut", "RfidTag", "dbo.tblStudent");
            DropForeignKey("dbo.tblStudentIn", "RfidTag", "dbo.tblStudent");
            DropForeignKey("dbo.tblSentMessages", "MobileNumber", "dbo.tblStudent");
            DropForeignKey("dbo.tblAnnouncement", "UserId", "dbo.tblUser");
            DropForeignKey("dbo.tblAdviser", "AdviserModel_AdviserId", "dbo.tblAdviser");
            DropIndex("dbo.tblStudentSection", new[] { "AdviserId" });
            DropIndex("dbo.tblStudentSection", new[] { "StudentId" });
            DropIndex("dbo.tblStudentSection", new[] { "SectionId" });
            DropIndex("dbo.tblStudentOut", new[] { "RfidTag" });
            DropIndex("dbo.tblStudentIn", new[] { "RfidTag" });
            DropIndex("dbo.tblSentMessages", new[] { "MobileNumber" });
            DropIndex("dbo.tblAnnouncement", new[] { "UserId" });
            DropIndex("dbo.tblAdviser", new[] { "AdviserModel_AdviserId" });
            DropTable("dbo.tblStudentSection");
            DropTable("dbo.tblStudentOut");
            DropTable("dbo.tblStudentIn");
            DropTable("dbo.tblStudent");
            DropTable("dbo.tblSentMessages");
            DropTable("dbo.tblSection");
            DropTable("dbo.tblUser");
            DropTable("dbo.tblAnnouncement");
            DropTable("dbo.tblAdviser");
        }
    }
}
