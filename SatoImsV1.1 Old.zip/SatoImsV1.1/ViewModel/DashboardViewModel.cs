﻿using SatoImsV1._1.ViewModel.Base;

namespace SatoImsV1._1.ViewModel
{
    public class DashboardViewModel : ViewModelBase
    {
    }
}
