﻿namespace SatoImsV1._1.Model
{
    public interface IEntity
    {
        int Id { get; set; }
    }
}
