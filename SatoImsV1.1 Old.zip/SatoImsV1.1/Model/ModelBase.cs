﻿namespace SatoImsV1._1.Model
{
    public abstract class ModelBase : IEntity
    {
        public int Id { get; set; }
    }
}
