﻿namespace SatoImsV1._1.Data.Dtos
{
    public class POItemDto
    {
        public string imagesource { get; set; }
        public string item_no { get; set; }
        public string item_desc { get; set; }
        public string unit { get; set; }
        public int qty { get; set; }
        public double price { get; set; }
        public double amount { get; set; }
    }
}
